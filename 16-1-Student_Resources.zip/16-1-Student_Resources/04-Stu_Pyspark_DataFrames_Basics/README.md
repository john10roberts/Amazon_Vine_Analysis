## Demographic DataFrame Basics

### Instructions

In this activity, you will get the chance to explore Spark DataFrames. Follow the comments in the Notebook to clean and display stock data using Spark DataFrames. Remember to consult the [documentation](http://spark.apache.org/docs/latest/api/python/index.html).
